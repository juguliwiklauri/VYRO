import 'package:cloud_firestore/cloud_firestore.dart';

class VyroVideo {
  const VyroVideo({
    required this.id,
    required this.ownerId,
    required this.videoUrl,
    required this.caption,
    required this.createdAt,
    this.ownerUsername = '',
    this.thumbnailUrl,
    this.likeCount = 0,
    this.commentCount = 0,
    this.hashtags = const [],
  });

  final String id;
  final String ownerId;
  final String videoUrl;
  final String caption;
  final DateTime createdAt;
  final String ownerUsername;
  final String? thumbnailUrl;
  final int likeCount;
  final int commentCount;
  final List<String> hashtags;

  factory VyroVideo.fromFirestore(
    DocumentSnapshot<Map<String, dynamic>> snapshot,
  ) {
    final data = snapshot.data() ?? <String, dynamic>{};
    final timestamp = data['createdAt'];
    return VyroVideo(
      id: snapshot.id,
      ownerId: data['ownerId'] as String? ?? '',
      videoUrl: data['videoUrl'] as String? ?? '',
      caption: data['caption'] as String? ?? '',
      createdAt: timestamp is Timestamp
          ? timestamp.toDate()
          : DateTime.fromMillisecondsSinceEpoch(0),
      ownerUsername: data['ownerUsername'] as String? ?? '',
      thumbnailUrl: data['thumbnailUrl'] as String?,
      likeCount: (data['likeCount'] as num?)?.toInt() ?? 0,
      commentCount: (data['commentCount'] as num?)?.toInt() ?? 0,
      hashtags: (data['hashtags'] as List<dynamic>? ?? const [])
          .whereType<String>()
          .toList(growable: false),
    );
  }

  Map<String, Object?> toFirestore() => {
        'ownerId': ownerId,
        'ownerUsername': ownerUsername,
        'videoUrl': videoUrl,
        'thumbnailUrl': thumbnailUrl,
        'caption': caption,
        'hashtags': hashtags,
        'createdAt': Timestamp.fromDate(createdAt),
        'likeCount': likeCount,
        'commentCount': commentCount,
      };
}
