import 'package:cloud_firestore/cloud_firestore.dart';

import '../domain/video.dart';
import 'video_repository.dart';

class FirestoreVideoRepository implements VideoRepository {
  FirestoreVideoRepository({FirebaseFirestore? firestore})
      : _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _firestore;
  CollectionReference<Map<String, dynamic>> get _videos =>
      _firestore.collection('videos');

  @override
  Stream<List<VyroVideo>> watchLatest({int limit = 20}) => _videos
      .orderBy('createdAt', descending: true)
      .limit(limit)
      .snapshots()
      .map((snapshot) => snapshot.docs.map(VyroVideo.fromFirestore).toList());

  @override
  Future<String> publish(VyroVideo video) async {
    final reference = video.id.isEmpty ? _videos.doc() : _videos.doc(video.id);
    await reference.set(video.toFirestore());
    return reference.id;
  }
}
