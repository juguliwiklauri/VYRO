import '../domain/video.dart';

abstract interface class VideoRepository {
  Stream<List<VyroVideo>> watchLatest({int limit = 20});
  Future<String> publish(VyroVideo video);
}
