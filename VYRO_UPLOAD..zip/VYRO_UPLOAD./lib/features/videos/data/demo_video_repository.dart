import 'dart:async';

import '../domain/video.dart';
import 'video_repository.dart';

/// In-memory placeholder used until Firebase is configured.
class DemoVideoRepository implements VideoRepository {
  final _controller = StreamController<List<VyroVideo>>.broadcast();

  @override
  Stream<List<VyroVideo>> watchLatest({int limit = 20}) =>
      _controller.stream;

  @override
  Future<String> publish(VyroVideo video) async {
    _controller.add([video]);
    return video.id;
  }

  Future<void> dispose() => _controller.close();
}
