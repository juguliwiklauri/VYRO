import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';

class VideoStorageService {
  VideoStorageService({FirebaseStorage? storage})
      : _storage = storage ?? FirebaseStorage.instance;

  final FirebaseStorage _storage;

  /// Uploads a selected local video to videos/{userId}/{fileName}.
  /// Authentication and file-size/type validation must happen before calling.
  Future<String> uploadVideo({
    required String userId,
    required String fileName,
    required File file,
  }) async {
    final reference = _storage.ref('videos/$userId/$fileName');
    final snapshot = await reference.putFile(
      file,
      SettableMetadata(contentType: 'video/mp4'),
    );
    return snapshot.ref.getDownloadURL();
  }
}
