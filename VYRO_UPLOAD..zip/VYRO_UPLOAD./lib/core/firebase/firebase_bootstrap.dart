import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

/// Initializes Firebase using the native Android/iOS configuration files.
/// The app deliberately falls back to demo mode when Firebase is not configured.
class FirebaseBootstrap {
  FirebaseBootstrap._();

  static bool isReady = false;

  static Future<void> initialize() async {
    try {
      await Firebase.initializeApp();
      isReady = true;
      debugPrint('VYRO: Firebase initialized.');
    } on FirebaseException catch (error) {
      isReady = false;
      debugPrint('VYRO: Firebase is not configured yet: ${error.message}');
    } catch (error) {
      isReady = false;
      debugPrint('VYRO: Starting in demo mode ($error).');
    }
  }
}
