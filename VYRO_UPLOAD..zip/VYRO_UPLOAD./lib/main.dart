import 'package:flutter/material.dart';

import 'core/firebase/firebase_bootstrap.dart';
import 'l10n/app_localizations.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await FirebaseBootstrap.initialize();
  runApp(const VyroApp());
}

const bg = Color(0xFF08090D);
const panel = Color(0xFF151720);
const accent = Color(0xFF9B5CFF);

class VyroApp extends StatelessWidget {
  const VyroApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VYRO',
      localizationsDelegates: AppLocalizations.localizationsDelegates,
      supportedLocales: AppLocalizations.supportedLocales,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(
          primary: accent,
          secondary: Color(0xFFCA8BFF),
          surface: panel,
        ),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int tab = 0;
  final pages = const [
    FeedPage(),
    DiscoverPage(),
    UploadPage(),
    InboxPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    return Scaffold(
      body: IndexedStack(index: tab, children: pages),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF101117),
        indicatorColor: accent.withOpacity(.18),
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: l10n.home),
          NavigationDestination(icon: Icon(Icons.search), label: l10n.discover),
          NavigationDestination(icon: Icon(Icons.add_box_outlined), selectedIcon: Icon(Icons.add_box), label: l10n.create),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: l10n.inbox),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: l10n.profile),
        ],
      ),
    );
  }
}

class FeedPage extends StatefulWidget {
  const FeedPage({super.key});
  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  bool following = false;
  final items = const [
    ('@luna.motion', 'City lights after midnight ✨', '01'),
    ('@kai.travels', 'A little escape into the mountains', '02'),
    ('@mira.cooks', 'Quick comfort food for tonight', '03'),
  ];

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final item = items[following ? 1 : 0];
    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF24213B), Color(0xFF11131D), Color(0xFF08090D)],
            ),
          ),
        ),
        Positioned.fill(
          child: CustomPaint(painter: GlowPainter(seed: following ? 2 : 1)),
        ),
        SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 14),
                child: Row(
                  children: [
                    const Text('VYRO', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 3)),
                    const Spacer(),
                    _FeedTab(label: l10n.following, selected: following, onTap: () => setState(() => following = true)),
                    const SizedBox(width: 18),
                    _FeedTab(label: l10n.forYou, selected: !following, onTap: () => setState(() => following = false)),
                  ],
                ),
              ),
              const Spacer(),
              const Icon(Icons.play_circle_outline, size: 76, color: Colors.white70),
              const SizedBox(height: 12),
              const Text('VYRO VIDEO FEED', style: TextStyle(letterSpacing: 3, fontWeight: FontWeight.w700, color: Colors.white70)),
              const Text('Your next scroll starts here', style: TextStyle(color: Colors.white54)),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 0, 14, 24),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item.$1, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          const SizedBox(height: 7),
                          Text(item.$2, style: const TextStyle(fontSize: 14)),
                          const SizedBox(height: 10),
                          const Row(children: [Icon(Icons.music_note, size: 16), SizedBox(width: 5), Text('Original audio · VYRO', style: TextStyle(fontSize: 12))]),
                        ],
                      ),
                    ),
                    const Column(
                      children: [
                        _ActionIcon(icon: Icons.favorite_border, label: 'Like'),
                        SizedBox(height: 18),
                        _ActionIcon(icon: Icons.mode_comment_outlined, label: 'Comment'),
                        SizedBox(height: 18),
                        _ActionIcon(icon: Icons.bookmark_border, label: 'Save'),
                        SizedBox(height: 18),
                        _ActionIcon(icon: Icons.share_outlined, label: 'Share'),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _FeedTab extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _FeedTab({required this.label, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Column(children: [
      Text(label, style: TextStyle(fontWeight: selected ? FontWeight.w800 : FontWeight.w500, color: selected ? Colors.white : Colors.white60)),
      const SizedBox(height: 5),
      if (selected) Container(width: 24, height: 3, decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(9))),
    ]),
  );
}

class _ActionIcon extends StatelessWidget {
  final IconData icon;
  final String label;
  const _ActionIcon({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Column(children: [
    Icon(icon, size: 29, color: Colors.white),
    const SizedBox(height: 4),
    Text(label, style: const TextStyle(fontSize: 10, color: Colors.white70)),
  ]);
}

class DiscoverPage extends StatelessWidget {
  const DiscoverPage({super.key});
  @override
  Widget build(BuildContext context) => SafeArea(
    child: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(AppLocalizations.of(context)!.discover, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
        const SizedBox(height: 18),
        TextField(decoration: InputDecoration(
          hintText: AppLocalizations.of(context)!.searchHint,
          prefixIcon: const Icon(Icons.search),
          filled: true, fillColor: panel,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        )),
        const SizedBox(height: 24),
        Text(AppLocalizations.of(context)!.trendingTopics, style: TextStyle(letterSpacing: 2, color: Colors.white60, fontSize: 11)),
        const SizedBox(height: 14),
        const Wrap(spacing: 9, runSpacing: 9, children: [
          _Topic('#travel'), _Topic('#daily'), _Topic('#food'), _Topic('#music'), _Topic('#fashion'), _Topic('#georgia'),
        ]),
      ]),
    ),
  );
}

class _Topic extends StatelessWidget {
  final String text;
  const _Topic(this.text);
  @override
  Widget build(BuildContext context) => Chip(
    label: Text(text),
    backgroundColor: panel,
    side: BorderSide(color: accent.withOpacity(.35)),
  );
}

class UploadPage extends StatelessWidget {
  const UploadPage({super.key});
  @override
  Widget build(BuildContext context) => SafeArea(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(AppLocalizations.of(context)!.create, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
        const Spacer(),
        Center(child: Container(
          width: 190, height: 240,
          decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(24), border: Border.all(color: accent.withOpacity(.5))),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.video_call_outlined, size: 58, color: accent),
            SizedBox(height: 12),
            Text(AppLocalizations.of(context)!.addVideo, style: const TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 5),
            Text(AppLocalizations.of(context)!.recordOrChoose, style: const TextStyle(color: Colors.white54, fontSize: 12)),
          ]),
        )),
        const SizedBox(height: 24),
        SizedBox(width: double.infinity, child: FilledButton.icon(
          onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Video picker will be connected in the next build.'))),
          icon: const Icon(Icons.add),
          label: Text(AppLocalizations.of(context)!.selectVideo),
          style: FilledButton.styleFrom(backgroundColor: accent, padding: const EdgeInsets.all(16)),
        )),
        const Spacer(),
      ]),
    ),
  );
}

class InboxPage extends StatelessWidget {
  const InboxPage({super.key});
  @override
  Widget build(BuildContext context) => SafeArea(
    child: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(AppLocalizations.of(context)!.inbox, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        Text(AppLocalizations.of(context)!.messagesEmpty, style: const TextStyle(color: Colors.white60)),
      ]),
    ),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => SafeArea(
    child: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(children: [
        Align(alignment: Alignment.centerLeft, child: Text(AppLocalizations.of(context)!.profile, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800))),
        const SizedBox(height: 32),
        const CircleAvatar(radius: 44, backgroundColor: panel, child: Icon(Icons.person, size: 42, color: accent)),
        const SizedBox(height: 12),
        const Text('@yourname', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text(AppLocalizations.of(context)!.profileTagline, style: TextStyle(color: Colors.white54)),
        const SizedBox(height: 24),
        Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          _Stat(value: '0', label: AppLocalizations.of(context)!.followingStat),
          _Stat(value: '0', label: AppLocalizations.of(context)!.followers),
          _Stat(value: '0', label: AppLocalizations.of(context)!.likes),
        ]),
        const SizedBox(height: 24),
        OutlinedButton(onPressed: () {}, child: Text(AppLocalizations.of(context)!.editProfile)),
      ]),
    ),
  );
}

class _Stat extends StatelessWidget {
  final String value, label;
  const _Stat({required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Column(children: [
    Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
    Text(label, style: const TextStyle(color: Colors.white54, fontSize: 12)),
  ]);
}

class GlowPainter extends CustomPainter {
  final int seed;
  GlowPainter({required this.seed});
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..maskFilter = const MaskFilter.blur(BlurStyle.normal, 65);
    p.color = accent.withOpacity(.16);
    canvas.drawCircle(Offset(size.width * .75, size.height * .32), size.width * .28, p);
    p.color = const Color(0xFF3A7BFF).withOpacity(.10);
    canvas.drawCircle(Offset(size.width * .18, size.height * .72), size.width * .30, p);
  }
  @override
  bool shouldRepaint(covariant GlowPainter oldDelegate) => oldDelegate.seed != seed;
}
