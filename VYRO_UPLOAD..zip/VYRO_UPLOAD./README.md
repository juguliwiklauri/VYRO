# VYRO — Flutter starter (Stage 2)

VYRO is a short-video social app foundation for Android and iOS, with a premium dark UI, a For You / Following feed concept, and a multilingual product direction.

## Included

- Existing dark Flutter UI: Home, Discover, Create, Inbox, Profile.
- For You / Following feed tabs (currently demo UI, not personalized ranking).
- Firebase initialization with a safe demo-mode fallback when native Firebase configuration is absent.
- Email/password authentication repository.
- Video domain model and Firestore repository boundary.
- Firebase Storage upload service for authenticated users.
- Starter Firestore and Storage security rules.
- Firebase project wiring in `firebase.json`.
- English and Georgian localization resources with Flutter `gen-l10n` configured.

## Current limitations — do not treat as production-ready

- No Firebase project has been created or connected for you.
- `google-services.json` and `GoogleService-Info.plist` are not included; they must come from your own Firebase project.
- The current screens still use sample/demo content. The new repositories are foundations and are not yet wired into the feed or upload UI.
- Video transcoding, thumbnails, content moderation, abuse reporting, privacy controls, rate limits, push-notification flows, and production security review remain to be implemented.
- Firestore and Storage rules are starter policies and must be emulator-tested and security-reviewed before public launch. Messaging rules still need full schema validation, abuse controls, and privacy review.
- English and Georgian resources cover the core navigation and key screen labels; some secondary demo copy remains English.

## Firebase setup (one-time account action)

1. Create a Firebase project in the Firebase Console.
2. Register **two apps** in the same Firebase project: Android and iOS. Use the application identifiers you choose for VYRO.
3. Install FlutterFire CLI on a computer with Flutter installed, then run `flutterfire configure` from this project. This generates platform configuration (including `lib/firebase_options.dart`) and adds the required native files.
4. Enable **Email/Password** in Firebase Authentication.
5. Create a Cloud Firestore database and enable Firebase Storage.
6. Deploy the included rules with `firebase deploy --only firestore:rules,storage` after installing and signing in to the Firebase CLI.
7. Run `flutter pub get`, then `flutter run` on Android or iOS.

Never send passwords, private signing keys, or service-account JSON files in chat. Firebase client configuration files are project-specific; obtain them directly from your Firebase Console / FlutterFire CLI.

## Project structure

```text
lib/
  core/firebase/firebase_bootstrap.dart
  l10n/app_en.arb
  l10n/app_ka.arb
  features/
    auth/data/auth_repository.dart
    media/video_storage_service.dart
    videos/
      domain/video.dart
      data/video_repository.dart
      data/firestore_video_repository.dart
      data/demo_video_repository.dart
  main.dart
firestore.rules
storage.rules
firebase.json
firestore.indexes.json
```

## Firestore data model (initial)

- `users/{uid}` — username, displayName, photoUrl, bio, createdAt
- `videos/{videoId}` — ownerId, ownerUsername, videoUrl, thumbnailUrl, caption, hashtags, createdAt, likeCount, commentCount
- `videos/{videoId}/likes/{uid}`
- `videos/{videoId}/comments/{commentId}`
- `users/{uid}/following/{targetUid}`
- `users/{uid}/followers/{followerUid}`
- `conversations/{conversationId}/messages/{messageId}`

## Localization

English (`app_en.arb`) and Georgian (`app_ka.arb`) resources are included. Flutter generates `AppLocalizations` from these files during the build. Add a new ARB entry for every new user-facing string.

## Validation status

The Flutter SDK is not available in the current build environment, so `flutter pub get`, analyzer, device builds, and runtime tests have **not** been run. The JSON configuration files were syntax-checked when this package was prepared.
